﻿using Sesiones.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sesiones.Permisos
{
    public class PermisosRolAttribute : ActionFilterAttribute
    {
        private Rol id_rol;
        public PermisosRolAttribute(Rol _id_rol) { 
            id_rol = _id_rol;
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (HttpContext.Current.Session["Usuario"] != null)
            {
                Usuario usuario = HttpContext.Current.Session["Usuario"] as Usuario;


                if (usuario.id_rol != this.id_rol)
                {

                    filterContext.Result = new RedirectResult("~/Home/SinPermiso");

                }
            }


            base.OnActionExecuted(filterContext);
        }
    }
}