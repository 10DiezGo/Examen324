﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


using Sesiones.Models;
using System.Data.SqlClient;
using System.Data;

namespace Sesiones.Logica
{
    public class LO_Usuario
    {


        public Usuario EncontrarUsuario(string correo, string clave)
        {
            Usuario objeto = new Usuario();


            using (SqlConnection conexion = new SqlConnection("Data Source=VIERNES ; Initial Catalog=BDDiego; Integrated Security=false; User ID=ex324; Password=123" ))
            {

                string query = "select Nombre,Correo,Clave,id_rol from Usuario where Correo = @pcorreo and Clave = @pclave";

                SqlCommand cmd = new SqlCommand(query, conexion);
                cmd.Parameters.AddWithValue("@pcorreo", correo);
                cmd.Parameters.AddWithValue("@pclave", clave);
                cmd.CommandType = CommandType.Text;


                conexion.Open();


                using (SqlDataReader dr = cmd.ExecuteReader())
                {

                    while (dr.Read())
                    {

                        objeto = new Usuario()
                        {
                            Nombre = dr["Nombre"].ToString(),
                            Correo = dr["Correo"].ToString(),
                            Clave = dr["Clave"].ToString(),
                            id_rol = (Rol)dr["Id_rol"],

                        };
                    }

                }
            }
            return objeto;

        }




    }
}