﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sesiones.Models
{
    public enum Rol
    {
        Administrador = 1,
        DirectorBancario = 2,
        Cajero = 3
    }
}